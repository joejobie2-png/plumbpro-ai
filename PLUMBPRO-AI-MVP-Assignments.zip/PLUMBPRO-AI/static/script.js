(function () {
  const button = document.getElementById("languageToggle");
  const storageKey = "plumbpro-language";
  let language = localStorage.getItem(storageKey) || "en";

  function applyLanguage() {
    document.documentElement.lang = language === "ta" ? "ta" : "en";
    document.querySelectorAll("[data-en][data-ta]").forEach((el) => {
      const value = el.dataset[language];
      if (value !== undefined) el.textContent = value;
    });
    if (button) button.textContent = language === "en" ? "தமிழ்" : "English";
    document.querySelectorAll("option[data-en][data-ta]").forEach((el) => {
      el.textContent = el.dataset[language];
    });
  }

  if (button) {
    button.addEventListener("click", () => {
      language = language === "en" ? "ta" : "en";
      localStorage.setItem(storageKey, language);
      applyLanguage();
    });
  }
  applyLanguage();
})();
