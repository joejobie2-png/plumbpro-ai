from flask import Flask, render_template, request, redirect, url_for, flash, jsonify
import sqlite3
from datetime import date, datetime
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / "plumbpro.db"

app = Flask(__name__)
app.secret_key = "change-this-before-online-deployment"

def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn

def init_db():
    with db() as con:
        con.executescript("""
        CREATE TABLE IF NOT EXISTS workers (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            phone TEXT DEFAULT '',
            skill TEXT NOT NULL DEFAULT 'Helper',
            daily_wage REAL NOT NULL DEFAULT 0,
            active INTEGER NOT NULL DEFAULT 1,
            created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS projects (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            client TEXT NOT NULL DEFAULT '',
            location TEXT DEFAULT '',
            billing_rate REAL NOT NULL DEFAULT 0,
            notes TEXT DEFAULT '',
            active INTEGER NOT NULL DEFAULT 1,
            created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS work_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            work_date TEXT NOT NULL,
            worker_id INTEGER NOT NULL,
            project_id INTEGER NOT NULL,
            days REAL NOT NULL DEFAULT 1,
            billing_rate REAL NOT NULL DEFAULT 0,
            wage_rate REAL NOT NULL DEFAULT 0,
            notes TEXT DEFAULT '',
            created_at TEXT NOT NULL,
            FOREIGN KEY(worker_id) REFERENCES workers(id),
            FOREIGN KEY(project_id) REFERENCES projects(id)
        );
        CREATE TABLE IF NOT EXISTS assignments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            worker_id INTEGER NOT NULL REFERENCES workers(id),
            project_id INTEGER NOT NULL REFERENCES projects(id),
            work_date TEXT NOT NULL,
            start_time TEXT NOT NULL,
            location TEXT NOT NULL,
            description TEXT NOT NULL,
            instructions TEXT DEFAULT '',
            created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS transactions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            txn_date TEXT NOT NULL,
            project_id INTEGER,
            kind TEXT NOT NULL CHECK(kind IN ('received','expense','wage_paid','advance')),
            amount REAL NOT NULL CHECK(amount >= 0),
            category TEXT NOT NULL DEFAULT '',
            paid_by TEXT DEFAULT '',
            notes TEXT DEFAULT '',
            created_at TEXT NOT NULL,
            FOREIGN KEY(project_id) REFERENCES projects(id)
        );
        """)

def today():
    return date.today().isoformat()

def money(value):
    try:
        return float(value or 0)
    except (TypeError, ValueError):
        return 0.0

def get_dashboard_data():
    with db() as con:
        worker_count = con.execute("SELECT COUNT(*) FROM workers WHERE active=1").fetchone()[0]
        project_count = con.execute("SELECT COUNT(*) FROM projects WHERE active=1").fetchone()[0]
        today_logs = con.execute("""
            SELECT COALESCE(SUM(days * billing_rate),0) AS revenue,
                   COALESCE(SUM(days * wage_rate),0) AS wages
            FROM work_logs WHERE work_date=?
        """, (today(),)).fetchone()
        week_start = date.today().fromordinal(date.today().toordinal() - date.today().weekday()).isoformat()
        week_logs = con.execute("""
            SELECT COALESCE(SUM(days*wage_rate),0) AS earned
            FROM work_logs WHERE work_date BETWEEN ? AND ?
        """, (week_start, today())).fetchone()
        received = con.execute("SELECT COALESCE(SUM(amount),0) FROM transactions WHERE kind='received'").fetchone()[0]
        expenses = con.execute("SELECT COALESCE(SUM(amount),0) FROM transactions WHERE kind='expense'").fetchone()[0]
        wages_paid = con.execute("SELECT COALESCE(SUM(amount),0) FROM transactions WHERE kind='wage_paid'").fetchone()[0]
        advances = con.execute("SELECT COALESCE(SUM(amount),0) FROM transactions WHERE kind='advance'").fetchone()[0]
        earned_revenue = con.execute("SELECT COALESCE(SUM(days*billing_rate),0) FROM work_logs").fetchone()[0]
        wages_earned = con.execute("SELECT COALESCE(SUM(days*wage_rate),0) FROM work_logs").fetchone()[0]
        pending = earned_revenue - received
        # Cash-based remaining estimate, not accounting/tax advice.
        estimate = earned_revenue - wages_earned - expenses
        recent = con.execute("""
            SELECT w.work_date, wr.name worker, p.name project, w.days,
                   w.billing_rate, w.wage_rate,
                   (w.days*w.billing_rate) revenue, (w.days*w.wage_rate) wages
            FROM work_logs w
            JOIN workers wr ON wr.id=w.worker_id
            JOIN projects p ON p.id=w.project_id
            ORDER BY w.work_date DESC, w.id DESC LIMIT 8
        """).fetchall()
    return {
        "worker_count": worker_count, "project_count": project_count,
        "today_revenue": today_logs["revenue"], "today_wages": today_logs["wages"],
        "week_wages": week_logs["earned"], "received": received, "expenses": expenses,
        "wages_paid": wages_paid, "advances": advances, "earned_revenue": earned_revenue,
        "wages_earned": wages_earned, "pending": pending, "estimate": estimate,
        "recent": recent
    }

@app.route("/")
def index():
    data = get_dashboard_data()
    return render_template("index.html", data=data, today=today())

@app.route("/workers", methods=["GET", "POST"])
def workers():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        if not name:
            flash("Worker name is required.", "error")
            return redirect(url_for("workers"))
        with db() as con:
            con.execute("""INSERT INTO workers(name,phone,skill,daily_wage,created_at)
                           VALUES(?,?,?,?,?)""",
                        (name, request.form.get("phone","").strip(),
                         request.form.get("skill","Helper"),
                         money(request.form.get("daily_wage")), datetime.now().isoformat(timespec="seconds")))
        flash("Worker added successfully.", "success")
        return redirect(url_for("workers"))
    with db() as con:
        rows = con.execute("SELECT * FROM workers ORDER BY active DESC, name").fetchall()
    return render_template("workers.html", workers=rows)

@app.post("/workers/<int:worker_id>/toggle")
def toggle_worker(worker_id):
    with db() as con:
        con.execute("UPDATE workers SET active=CASE active WHEN 1 THEN 0 ELSE 1 END WHERE id=?", (worker_id,))
    flash("Worker status updated.", "success")
    return redirect(url_for("workers"))

@app.route("/projects", methods=["GET", "POST"])
def projects():
    if request.method == "POST":
        name = request.form.get("name","").strip()
        if not name:
            flash("Project name is required.", "error")
            return redirect(url_for("projects"))
        with db() as con:
            con.execute("""INSERT INTO projects(name,client,location,billing_rate,notes,created_at)
                           VALUES(?,?,?,?,?,?)""",
                        (name, request.form.get("client","").strip(),
                         request.form.get("location","").strip(),
                         money(request.form.get("billing_rate")),
                         request.form.get("notes","").strip(),
                         datetime.now().isoformat(timespec="seconds")))
        flash("Project added successfully.", "success")
        return redirect(url_for("projects"))
    with db() as con:
        rows = con.execute("SELECT * FROM projects ORDER BY active DESC, name").fetchall()
    return render_template("projects.html", projects=rows)

@app.post("/projects/<int:project_id>/toggle")
def toggle_project(project_id):
    with db() as con:
        con.execute("UPDATE projects SET active=CASE active WHEN 1 THEN 0 ELSE 1 END WHERE id=?", (project_id,))
    flash("Project status updated.", "success")
    return redirect(url_for("projects"))

@app.route("/work", methods=["GET", "POST"])
def work():
    if request.method == "POST":
        work_date = request.form.get("work_date") or today()
        worker_id = request.form.get("worker_id")
        project_id = request.form.get("project_id")
        days = money(request.form.get("days", 1))
        if not worker_id or not project_id or days <= 0:
            flash("Select a worker, project and valid number of days.", "error")
            return redirect(url_for("work"))
        with db() as con:
            worker = con.execute("SELECT * FROM workers WHERE id=? AND active=1", (worker_id,)).fetchone()
            project = con.execute("SELECT * FROM projects WHERE id=? AND active=1", (project_id,)).fetchone()
            if not worker or not project:
                flash("Choose an active worker and project.", "error")
                return redirect(url_for("work"))
            billing_rate = money(request.form.get("billing_rate"))
            wage_rate = money(request.form.get("wage_rate"))
            con.execute("""INSERT INTO work_logs(work_date,worker_id,project_id,days,billing_rate,wage_rate,notes,created_at)
                           VALUES(?,?,?,?,?,?,?,?)""",
                        (work_date, worker_id, project_id, days, billing_rate, wage_rate,
                         request.form.get("notes","").strip(), datetime.now().isoformat(timespec="seconds")))
        flash("Daily work saved.", "success")
        return redirect(url_for("work"))
    with db() as con:
        workers = con.execute("SELECT * FROM workers WHERE active=1 ORDER BY name").fetchall()
        projects = con.execute("SELECT * FROM projects WHERE active=1 ORDER BY name").fetchall()
        logs = con.execute("""
            SELECT w.*, wr.name worker, p.name project
            FROM work_logs w JOIN workers wr ON wr.id=w.worker_id
            JOIN projects p ON p.id=w.project_id
            ORDER BY w.work_date DESC,w.id DESC LIMIT 50
        """).fetchall()
    return render_template("work.html", workers=workers, projects=projects, logs=logs, today=today())

@app.route("/transactions", methods=["GET", "POST"])
def transactions():
    if request.method == "POST":
        kind = request.form.get("kind")
        amount = money(request.form.get("amount"))
        txn_date = request.form.get("txn_date") or today()
        if kind not in ("received","expense","wage_paid","advance") or amount <= 0:
            flash("Choose a transaction type and enter an amount greater than zero.", "error")
            return redirect(url_for("transactions"))
        project_id = request.form.get("project_id") or None
        category = request.form.get("category", "").strip()
        worker_id = request.form.get("worker_id", "").strip()
        if kind in ("wage_paid", "advance"):
            if not worker_id:
                flash("Choose the worker for a wage payment or advance.", "error")
                return redirect(url_for("transactions"))
            category = worker_id
        with db() as con:
            con.execute("""INSERT INTO transactions(txn_date,project_id,kind,amount,category,paid_by,notes,created_at)
                           VALUES(?,?,?,?,?,?,?,?)""",
                        (txn_date, project_id, kind, amount,
                         category,
                         request.form.get("paid_by","").strip(),
                         request.form.get("notes","").strip(),
                         datetime.now().isoformat(timespec="seconds")))
        flash("Transaction saved.", "success")
        return redirect(url_for("transactions"))
    with db() as con:
        projects = con.execute("SELECT * FROM projects ORDER BY name").fetchall()
        workers = con.execute("SELECT id,name FROM workers WHERE active=1 ORDER BY name").fetchall()
        rows = con.execute("""
            SELECT t.*, p.name project FROM transactions t
            LEFT JOIN projects p ON p.id=t.project_id
            ORDER BY t.txn_date DESC,t.id DESC LIMIT 100
        """).fetchall()
    return render_template("transactions.html", projects=projects, workers=workers, transactions=rows, today=today())

@app.route("/assignments", methods=["GET", "POST"])
def assignments():
    from urllib.parse import quote
    if request.method == "POST":
        worker_id = request.form.get("worker_id")
        project_id = request.form.get("project_id")
        work_date = request.form.get("work_date", "").strip()
        start_time = request.form.get("start_time", "").strip()
        location = request.form.get("location", "").strip()
        description = request.form.get("description", "").strip()
        instructions = request.form.get("instructions", "").strip()
        with db() as con:
            worker = con.execute("SELECT * FROM workers WHERE id=? AND active=1", (worker_id,)).fetchone()
            project = con.execute("SELECT * FROM projects WHERE id=? AND active=1", (project_id,)).fetchone()
            if not worker or not project or not all([work_date,start_time,location,description]):
                flash("Complete all required fields.", "error")
                return redirect(url_for("assignments"))
            con.execute("""INSERT INTO assignments(worker_id,project_id,work_date,start_time,location,description,instructions,created_at)
                         VALUES(?,?,?,?,?,?,?,?)""", (worker_id,project_id,work_date,start_time,location,description,instructions,datetime.now().isoformat(timespec="seconds")))
        flash("Assignment saved. Open WhatsApp and press Send to notify the worker.", "success")
        return redirect(url_for("assignments"))
    with db() as con:
        workers = con.execute("SELECT * FROM workers WHERE active=1 ORDER BY name").fetchall()
        projects = con.execute("SELECT * FROM projects WHERE active=1 ORDER BY name").fetchall()
        rows = con.execute("""SELECT a.*,w.name worker,w.phone,p.name project,p.client
            FROM assignments a JOIN workers w ON a.worker_id=w.id JOIN projects p ON a.project_id=p.id
            ORDER BY a.work_date DESC,a.id DESC LIMIT 100""").fetchall()
    assignments_list=[]
    for row in rows:
        r=dict(row)
        digits=''.join(c for c in (r['phone'] or '') if c.isdigit())
        if len(digits)==10: digits='91'+digits  # Default Indian country code
        message=(f"🔧 PLUMBPRO AI - Work Assignment\n\nHello {r['worker']}!\n"
                 f"📅 Date: {r['work_date']}\n⏰ Reporting time: {r['start_time']}\n"
                 f"📍 Location: {r['location']}\n🏗️ Project: {r['project']}\n"
                 f"🛠️ Work: {r['description']}\n📌 Instructions: {r['instructions'] or 'None'}\n"
                 "Please confirm with your supervisor. Thank you!")
        r['wa_url']=f"https://wa.me/{digits}?text={quote(message)}" if 10 <= len(digits) <= 15 else None
        assignments_list.append(r)
    return render_template("assignments.html", workers=workers, projects=projects, assignments=assignments_list, today=today())

@app.route("/reports")
def reports():
    with db() as con:
        projects = con.execute("""
            SELECT p.id,p.name,p.client,
              COALESCE((SELECT SUM(days*billing_rate) FROM work_logs WHERE project_id=p.id),0) revenue,
              COALESCE((SELECT SUM(days*wage_rate) FROM work_logs WHERE project_id=p.id),0) wages,
              COALESCE((SELECT SUM(amount) FROM transactions WHERE project_id=p.id AND kind='expense'),0) expenses,
              COALESCE((SELECT SUM(amount) FROM transactions WHERE project_id=p.id AND kind='received'),0) received
            FROM projects p ORDER BY p.name
        """).fetchall()
        workers = con.execute("""
            SELECT wr.id,wr.name,wr.daily_wage,
             COALESCE(SUM(CASE WHEN w.work_date BETWEEN date('now','weekday 0','-6 days') AND date('now') THEN w.days*w.wage_rate ELSE 0 END),0) week_earned,
             COALESCE((SELECT SUM(amount) FROM transactions t WHERE t.kind='wage_paid' AND t.category=CAST(wr.id AS TEXT)
               AND t.txn_date BETWEEN date('now','weekday 0','-6 days') AND date('now')),0) week_paid,
             COALESCE((SELECT SUM(amount) FROM transactions t WHERE t.kind='advance' AND t.category=CAST(wr.id AS TEXT)
               AND t.txn_date BETWEEN date('now','weekday 0','-6 days') AND date('now')),0) week_advance
            FROM workers wr LEFT JOIN work_logs w ON w.worker_id=wr.id
            GROUP BY wr.id ORDER BY wr.name
        """).fetchall()
        logs = con.execute("""
            SELECT w.work_date,wr.name worker,p.name project,w.days,w.billing_rate,w.wage_rate,
            w.days*w.billing_rate revenue,w.days*w.wage_rate wages
            FROM work_logs w JOIN workers wr ON wr.id=w.worker_id JOIN projects p ON p.id=w.project_id
            ORDER BY w.work_date DESC,w.id DESC LIMIT 100
        """).fetchall()
    data = get_dashboard_data()
    return render_template("reports.html", projects=projects, workers=workers, logs=logs, data=data)

@app.route("/api/project/<int:project_id>")
def project_info(project_id):
    with db() as con:
        row = con.execute("SELECT billing_rate FROM projects WHERE id=?", (project_id,)).fetchone()
    return jsonify(dict(row) if row else {})

@app.route("/api/worker/<int:worker_id>")
def worker_info(worker_id):
    with db() as con:
        row = con.execute("SELECT daily_wage,skill FROM workers WHERE id=?", (worker_id,)).fetchone()
    return jsonify(dict(row) if row else {})

@app.route("/health")
def health():
    return {"status": "ok"}

init_db()

if __name__ == "__main__":
    app.run(debug=True)
