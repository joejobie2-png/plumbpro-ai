# PLUMBPRO AI — MVP

A local, mobile-friendly Flask + SQLite app for a small plumbing contractor business.

## Features
- Tamil / English interface toggle
- Worker registration and skill levels
- Projects, engineers, institutions and default billing rates
- Daily work entries with separate client billing and worker wage rates
- Revenue earned and wages earned calculations
- Transaction tracking: client receipts, expenses, wage payments, advances
- Project-wise financial summaries and printable reports

## Run on Windows
1. Install Python 3.11+ from python.org if needed. During install, enable "Add Python to PATH".
2. Extract this folder.
3. Open the folder in VS Code.
4. Double-click `run.bat`, or run these commands in the VS Code terminal:
   ```powershell
   py -3 -m venv venv
   .\venv\Scripts\Activate.ps1
   python -m pip install -r requirements.txt
   python app.py
   ```
5. Open http://127.0.0.1:5000 in your browser.

The SQLite database `plumbpro.db` is created automatically in the project folder.

## Important notes
- This is an MVP, intended for local testing. It has no login/authentication yet.
- Do not expose it directly to the public internet or enter sensitive personal data before adding authentication and backups.
- Back up `plumbpro.db` regularly by stopping the app and copying the file.
- The app distinguishes revenue earned (from daily work entries) from cash received (transactions).
- Estimated margin is revenue earned minus recorded worker wages and recorded business expenses. It excludes unrecorded costs, overheads and taxes.
- For wage payment / advance transactions, the current MVP lets you enter a worker ID in the Category field for the worker-wise report. A future iteration should replace this with a worker dropdown.
- Use real agreed rates and verify calculations before relying on the reports for payments.

## Assign & Notify (WhatsApp)
1. Add a worker with their WhatsApp phone number (Indian 10-digit numbers supported; international numbers should include country code).
2. Add a project.
3. Open **Assign & Notify**, enter date, time, location, and work instructions, and save.
4. Click **Open WhatsApp** for the saved assignment, then press **Send** in WhatsApp.
This does **not** send automatically; fully automatic messages require a separate approved WhatsApp Business Platform integration.
